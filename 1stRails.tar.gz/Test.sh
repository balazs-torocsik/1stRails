#!/bin/bash
 
showopts () {
  while getopts ":pq:" optname
    do
      case "$optname" in
        "--list |-l" )
          #echo "Option $optname is specified"
          curl http://localhost:3000/articles | sed -e 's/<[^>]*>//g' | sed -e 's/^[ \t]*//'
          ;;
        "q")
          echo "Option $optname has value $OPTARG"
          ;;
        "?")
          echo "Unknown option $OPTARG"
          ;;
        ":")
          echo "No argument value for option $OPTARG"
          ;;
        *)
        # Should not occur
          echo "Unknown error while processing options"
          ;;
      esac
    done
  return $OPTIND
}
 
showargs () {
  for p in "$@"
    do
      echo "[$p]"
    done
}
 
optinfo=$(showopts "$@")
argstart=$?
arginfo=$(showargs "${@:$argstart}")
echo "Arguments are:"
echo "$arginfo"
echo "Options are:"
echo "$optinfo"

      curl http://localhost:3000/articles # | sed -e 's/<[^>]*>//g' | sed -e 's/^[ \t]*//'
