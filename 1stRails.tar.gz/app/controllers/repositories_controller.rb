class RepositoriesController < ApplicationController
def new
  end
end
