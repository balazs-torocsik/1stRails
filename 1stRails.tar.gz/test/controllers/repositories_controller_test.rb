require 'test_helper'

class RepositoriesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
